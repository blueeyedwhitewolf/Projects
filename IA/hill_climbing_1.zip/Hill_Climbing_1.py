# Hill Climbing 1
# Standard Hill-Climbing Algorithm 
# Paulo Moura Oliveira Set/2017

import numpy as np
import matplotlib.pyplot as plt



def f(x):
    return  4*(np.sin(5*np.pi*x+0.5)**6) * np.exp(np.log2((x-0.8)**2))
 
It=100                      # Iterations Number
#x_plot = np.zeros((1,It))  # Vector for storing x values
#F_plot = np.zeros((1,It))  # Vector for storing f values
x_plot = np.array([])       # Vector for storing x values
F_plot = np.array([])       # Vector for storing f values    
lim_inf = 0                 # Interval low interval limit
lim_sup = 1.6               # Interval high interval limit
x1 = np.arange(lim_inf, lim_sup, 0.001)    # Vector for x values

plt.figure(1)
plt.plot(x1, f(x1), 'b-')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.axis([0, 1.6, -0.1, 2])
plt.show()

# Neighborhood radius
x_range = lim_sup-lim_inf
print(x_range)
x_radius = x_range/5
print(x_radius)

# Initial Starting point
x_current = lim_inf + np.random.uniform(0,1)*x_range
print(x_current)

# Evaluates and plots initial solution
F_current = f(x_current)
print(F_current)
plt.plot(x_current, F_current, 'bo',linewidth=6,markersize=10,markeredgewidth=3,fillstyle='none')
plt.show()


# Stores initial values for plotting
x_plot = np.append(x_plot,x_current) 
F_plot = np.append(F_plot,F_current) 

# Plots maximum solution
plt.plot(0.066,1.6332,'ko',linewidth=6,markersize=10,markeredgewidth=2,markerfacecolor = 'r');

plt.show()

# Standard hill-climbing with It Iterations
# Maximization
for j in range(2,It+1):
    # Generates a new random value
    x_new= (x_current-x_radius)+np.random.uniform(0,1)*2*x_radius;       
    # Bounds the new value to a certain interval
    if x_new < 0:
        x_new = 0;
    if x_new > 1.6:
        x_new = 1.6;
    # Evaluates new solution objective value 
    F_new = f(x_new)
    #print(F_new)  
    # Accepts new value if it is better than current value
    if F_new > F_current:
        x_current = x_new
        F_current = F_new
        plt.plot(x_current, F_current, 'ko',linewidth=6,markersize=10,markeredgewidth=2,markerfacecolor = 'g')
        plt.show()
    x_plot = np.append(x_plot,x_current) 
    F_plot = np.append(F_plot,F_current)

# Ploting the final results
plt.figure()                             # New figure  
x_It = np.arange(1,It+1,1)               # Vector with iterations for plotting      
F_ideal = np.empty(It)                   
F_ideal[:] = 1.6332                      # Vector with F_ideal
x_ideal = np.empty(It)                    
x_ideal[:] = 0.066                       # Vector with x_ideal


plt.subplot(211)   
line_f_ideal, = plt.plot(x_It,F_ideal,'k-',linewidth=2)
plt.show() 
line_f, = plt.plot(x_It,F_plot,'k--',linewidth=2)
plt.axis([1, It, -0.1, 3])
plt.xlabel('Iterations')
plt.ylabel('f(x)')
plt.legend([line_f_ideal,line_f],['Global Maximum','f(x)'])
plt.show()    

plt.subplot(212)
line_x_ideal, = plt.plot(x_It,x_ideal,'r-',linewidth=2)
plt.show()    
line_x, = plt.plot(x_It,x_plot,'r--',linewidth=2)
plt.axis([1, It, -0.1, 3])
plt.xlabel('Iterations')
plt.legend([line_x_ideal,line_x],['x Maximum','x'])
plt.ylabel('x')
plt.show()  









